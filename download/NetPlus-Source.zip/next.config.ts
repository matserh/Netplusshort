import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  typescript: {
    ignoreBuildErrors: true,
  },
  reactStrictMode: false,
  images: {
    remotePatterns: [
      {
        protocol: 'https',
        hostname: 'image.tmdb.org',
        pathname: '/t/p/**',
      },
    ],
  },
  allowedDevOrigins: [
    'preview-chat-5a1a5d89-48ca-41d3-8a51-9f749ec07f72.space.z.ai',
    '.space.z.ai',
    '.space.chatglm.site',
  ],
};

export default nextConfig;
